# Funnel references inspected 22 October 2026

Source observation, not proof of conversion. Desktop and mobile screenshots plus page text saved in 2026-10-22/. Some embedded testimonials stayed black; their presence/layout was observed, their videos were not watched. No forms were submitted.

## Goh https://gohconsulting.app/funnel/vsl
Observed: near-black background, restrained gold accent, centred logo and small audience callout, compact bold outcome/mechanism headline, short supporting line, large centred 16:9 presenter video. Immediately below: authority strip with named faces; then a two-column application/calendar module. Below it: client video story grid, then dense masonry-style case-study cards with amounts and specifics, then longer client breakdowns. It is VSL/application/proof-led, not a SaaS feature tour.
Persuasion interpretation: relevance → desirable commercial outcome → mechanism → explanation → credibility → application → deeper proof for unconvinced readers.
Preserve in adaptation: centred first screen, headline hierarchy, VSL prominence, application within the first few sections, concrete evidence placed near the decision. Keep genuine proof compact; do not create empty walls or transfer Goh results to a student.
Do not inherit: revenue numbers, named clients, their niche, testimonials, follower counts or proof volume. These are their marketing claims, not our evidence.
Screenshots: 2026-10-22/goh-desktop.png, goh-mobile.png. Page text: goh-text.txt.

## Scale Info https://scaleinfo.com.au/
Observed: near-black page, vivid lime accent, small uppercase audience callout, very large centred multiline outcome + timeframe + remedy headline. Short mechanism/credibility sentence below. A large video with strong unmute overlay dominates. One qualification CTA under the video with a short friction-reducing line. Captured lower region is mostly blank/footer; do not invent unseen sections or treat this as evidence the application works.
Preserve: immediate buyer/outcome clarity, one mechanism line, VSL then one CTA, minimal competing navigation. Outcome/timeframe/remedy must be developed for the student's offer, not copied or omitted reflexively.
Do not inherit: $100K/90-day promise, 150+ businesses, their guarantee. Use appropriate brand colour; lime is not a default theme for all student output.
Screenshots: 2026-10-22/scaleinfo-desktop.png and mobile.png.

## Goh confirmation https://gohconsulting.app/funnel/vsl/confirm
Observed: same black/gold identity, large status headline, preparation video, two visible next steps (calendar, FAQ videos), authority strip, success stories, extensive proof, FAQ-video grid and client breakdowns. The page continues the sale and prepares attendance; it is not a bare receipt.
Adapt: accurate booking status and logistics → short prep video → two or three actions → relevant proof/demo → objections that prevent attendance or purchase. Use actual state from scheduling; don't copy 'not confirmed' unless a real action is required.
Screenshot/text: 2026-10-22/goh-confirm.png and goh-confirm-text.txt.

## Tim Chao https://timchao.ai/confirmation-page
Observed: white/lilac page, centred status headline and short instruction, large preparation video, vertical numbered cards (watch, calendar confirmation, show up), practical preparation checklist, two member testimonial videos, then programme-content tabs. The email/calendar illustration is instructional, not the visitor's live calendar.
Adapt: keep practical next steps prominent and video optional for logistics; select objections and proof for the actual service. Do not copy coaching/community sections into a client's implementation funnel. Avoid punitive scarcity language unless it reflects actual policy.
Screenshot/text: 2026-10-22/tim-confirm-desktop.png, tim-confirm-mobile.png, tim-confirm-text.txt.

## Comparison rule
Before accepting a new page, compare its first screen and section sequence side by side with the chosen source. Explain deliberate deviations. A working form or correct mobile width does not pass this review.

## Blake's explicit refinement, 31 October 2026
Default to the compact Scale Info pattern. The VSL explains the pain, system and offer; remove repeated written pain/process sections, detailed guarantee/shared-accountability blocks and generic landing FAQs. The FAQ videos observed above belong to Goh's confirmation page. Roofline's generic landing FAQ section was our addition, not a documented reproduction of the compact landing reference.

Also provide a separate **Offer Testing Landing Page**: callout, outcome, brief mechanism and qualification, with no video area. This is Blake's requested text-only testing variant, not a claim that Scale Info was observed running a no-VSL page. Both variants need real downstream integrations before being called a live acquisition system.


## 5 November application of Blake’s call

The public service headline is the desired result plus its approved timeframe/remedy; the subheadline explains the mechanism in one sentence. The full service explanation is not pasted into the hero. Keep the compact VSL/application default. The longer J-374 programme page was a separate team demonstration, not a new student benchmark.

Qualified application leads to “Congratulations, you qualify” and booking. Actual booking leads to a separate thank-you page with accurate booking/attendance status, preparation video, invite action and supplied proof. Never label the pre-booking page as a post-booking example. Latest correction: the booking page must include a calendar section; a missing URL is a private integration task, with a labelled slot in a local review only.
