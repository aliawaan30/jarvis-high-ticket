# Module 2: The Irresistible Offer

Current full teaching text. Students study the course; Jarvis helps them understand and execute.

## The Irresistible Offer

Understand what makes an offer valuable before you create your own.

## What you will do in this module
Read each lesson, then do the exercise with Jarvis. If something does not make sense, ask it to explain the section using your business. The course teaches the process; Jarvis helps you apply it.

You will choose a service and a type of business to sell it to, understand the problem you solve, then create your offer with Jarvis.

First, learn what makes an offer worth buying. Then explore the services and niche ideas. Finally, follow the steps to create yours.

**By the end, you will know who you help, what you do for them and why they would pay. You will have an offer ready to use in your marketing.**

## What is an offer?
Your service is the work you do. Your offer tells the customer what they get, when they get it and why they should choose you.

> EXAMPLE: **The service:** Install an AI receptionist.

**The offer:** We’ll get your plumbing business 5 extra jobs in 30 days with an AI receptionist that answers your missed calls, or we work for free until we do.

The owner wants more jobs. The AI receptionist is how you help them get those jobs. The offer gives them a specific result, a timeframe and a guarantee.

An irresistible offer brings together a result the buyer wants, a believable way to achieve it, a clear timeframe and a guarantee you can stand behind.

## Understand what the problem costs
Before you decide what to sell or charge, understand how much the problem matters to the business.

An owner might say, “We miss a few calls at night.” That sounds small. But what are those missed calls worth?

### Example: missed calls at a plumbing business

> EXAMPLE: The business misses **30 new customer calls a month**.

If it usually turns **20% of those enquiries into jobs**, that is **6 potential jobs**.

At an average of **$2,500 per job**, that is **$15,000 in potential work each month**.

Now you can explain the value of the service. You are helping them win work they could be losing when nobody answers. In a survey of 1,000 US consumers, **82% said they would call a competitor if a business did not answer**. A missed call can become someone else’s job. [CallRail, September 2025](https://www.callrail.com/blog/missed-calls-cost-businesses-more-than-ever).

Before a sales call, ask Jarvis to research your niche and service and estimate the size of the problem. It can find typical job values and relevant industry research, then show a rough calculation and the questions to ask the owner.

```
Use the offer menu skill to research what this problem could cost a business in my niche. Find relevant sources, show a rough low, middle and high estimate, and give me the questions to check the numbers with the owner.

```
Use the owner’s numbers: how many genuine customer enquiries they miss, how many normally become jobs and what an average job is worth. The figures above show the calculation; not every missed call will become a sale.

### How this helps you create and price the offer
A problem costing $500 a month supports a different service and price from one costing $15,000 a month. Understanding the cost helps you decide whether the opportunity is worth pursuing and what the client could reasonably pay to fix it.

The $15,000 is potential sales revenue, not profit. You still need to understand the cost of doing those jobs, what your system can recover and what it costs you to deliver.

For an admin task, ask how many hours it takes and what that time costs. For slow quotes, ask how many customers are lost while waiting. The question stays the same: **what does this problem cost the business?**

You will use this again in the sales module, where you work through the numbers with the owner. Here, it helps you choose a worthwhile problem to build your offer around.

## Explain the offer from the buyer’s starting point
Two owners can have the same problem but understand it differently. One knows missed calls are costing jobs. Another thinks customers will just leave a message.

This is buyer awareness: **what they already know about the problem and the ways to solve it.** It changes what you need to explain in your offer and marketing.

![Eugene Schwartz’s five stages of awareness. Start with what the buyer already understands.](images/m2-the-five-stages-of-awareness-ladder.svg)

### Using the AI receptionist example
- **They have not noticed the problem.** Help them see how many enquiries go unanswered and what those could be worth.
- **They know the problem.** Explain how an AI receptionist answers those calls and helps book suitable jobs.
- **They know solutions exist.** Explain what your service handles: setup, their booking rules, calendar connection and ongoing support.
- **They are comparing providers.** Show your demo, relevant results and what is included.
- **They are ready to choose.** Make the timeframe, guarantee and next step clear.

You do not need to memorise these stages. Remember this: if the owner does not understand the problem yet, explain it before expecting them to want your solution. If they already understand it, spend less time explaining the basics and more time showing why your offer fits.

## AI services you can sell

Understand the service before choosing who to sell it to.

## Choose a service you want to explore
**These are service categories, not identical packages.** You adapt what you build to the business. Start with the result they need, then agree which tasks and connections belong in the service.

Here are eight services you can build an AI agency around. Each section explains what you sell, who might need it and what you would show a customer.

You are not choosing your final offer yet. Look for a service you understand and would like to deliver. Next, you will explore niches and match the service to a business with a worthwhile problem.

If you already know an industry well, keep it in mind as you browse. You can start with that niche and find the service it needs instead.

Understand what the client buys, who needs it and what you would show them.

## 1. AI receptionist
**What you sell.** An AI phone agent that answers when the team cannot, takes the caller’s details and books suitable jobs or appointments. The business keeps its number. Missed and after-hours calls forward to the agent, which checks the calendar and sends the team a summary.

**Who to sell it to.** Any business that takes customer calls. Think trades, clinics, salons and other local businesses. Start with one type so the questions, bookings and demo are easy to understand.

[See a provider offering AI call and triage agents](https://www.montra.com.au/)

### How it changes for each client
Some businesses only need the caller’s details and a message sent to the team. Others need appointment booking, call transfers, answers to routine questions or a new job created in their CRM. A webhook is a message from one system to another, such as telling the CRM to create that job after a call. Agree the actions, booking rules, connections and when a person takes over. A note-taking agent does not, by itself, deliver a promise of extra booked jobs.

**What to show.** A caller rings the demo number, asks about a service and gets the correct next step. Show a booking and a question that needs a human.

> EXAMPLE: We help local trade businesses turn missed calls into booked jobs with an AI receptionist that answers when their team cannot.

Understand what the client buys, who needs it and what you would show them.

## 2. AI appointment-setting agency

**What you sell.** You install and manage the follow-up that turns enquiries into booked consultations. The client gets the system set up around their service, connected to their calendar and looked after by you. They are paying for the work and the result, not just a software login.

**Who to sell it to.** Start with one niche where consultations lead to valuable sales. The business needs enough enquiries and staff available to take the appointments. If you also generate the enquiries with ads, that is a bigger service to deliver.

**A live agency offer.** [SyncPro Media](https://syncpromedia.com/) sells a dental-implant system combining Meta ads, AI follow-up and consultation booking. Its page advertises a $40K sales target in 40 days with continued free work if missed. Study how it connects the service to a result the buyer wants. Your own promise must fit what you can deliver.

### How it changes for each client
One clinic might need three questions and a booking link. Another needs follow-up across several lead sources, different calendars and a handoff for pricing questions. Agree which enquiries to handle, what makes someone suitable, when to follow up and what counts as a booked consultation.

**What to show.** Submit a test enquiry. Show the follow-up, qualification questions and appointment reaching the right calendar.

> EXAMPLE: We build and run the follow-up system that turns your dental enquiries into booked implant consultations, so your team can focus on treatment sales.

Understand what the client buys, who needs it and what you would show them.

## 3. Old-lead and unsold-quote recovery
**What you sell.** Reconnect with people who enquired or received a quote but never bought. The system follows up, handles agreed questions and brings interested buyers back to the sales team. It tracks which opportunities become paid work.

**Who to sell it to.** Businesses with a useful old database or unsold quotes. Roofers, builders, clinics and home-improvement companies often already have the opportunity sitting in their CRM.

**An agency selling it.** [Mixed Media Ventures](https://www.mixedmediaventures.com/database-reactivation-terms-and-conditions/) provides managed database-reactivation campaigns for clients and reseller agencies. Its [roofing case](https://www.mixedmediaventures.com/case-studies/) reports 127 qualified appointments over 90 days. These are the agency’s reported figures.

### How it changes for each client
You might follow up unsold quotes, older enquiries or previous customers. These need different messages and timing. Agree which records can be contacted, what the system can say, when a sales rep takes over and how the eventual sale is tracked.

**What to show.** Show an eligible old enquiry, the follow-up conversation and the sales-team handoff. Then show where the eventual sale would be recorded.

> EXAMPLE: We’ll get your roofing company 5 more jobs in 30 days from unsold estimates, or we work for free.

Understand what the client buys, who needs it and what you would show them.

## 4. Outbound appointment-setting agency

**What you sell.** You find suitable prospects, write and run the outreach, manage replies and book qualified sales conversations for the client. You build the system in their accounts and keep improving it while their team handles sales.

**Who to sell it to.** A B2B business with a clear offer and someone able to take sales calls. Start with your chosen niche, then check whether there are enough reachable buyers and whether a sale is worth the cost of getting the meeting.

**A live agency offer and client example.** [ColdIQ’s managed implementation](https://coldiq.com/implementation) builds and runs outbound in accounts the client owns. Its [Hemlane case](https://coldiq.com/case-studies/hemlane) explains targeting active rental-property owners and reports a 5.5% reply rate. The result is reported by the agency.

### How it changes for each client
The buyer list, channels, messages and qualification rules depend on the client’s offer and audience. Some need email only; others need email, LinkedIn and human calls working together. Agree what counts as a qualified meeting and who handles replies and sales.

**What to show.** Show the target account, relevant outreach, a reply and the handoff to the client’s sales calendar. Finding contacts alone is not the finished service.

> EXAMPLE: We find your ideal customers, start the conversations and book qualified sales calls for your team.

Understand what the client buys, who needs it and what you would show them.

## 5. Custom AI CRM
**What you sell.** Build a CRM around how the business actually works. Enquiries, quotes, jobs, documents and follow-ups sit together, with agreed tasks automated. Decide what it replaces and what it connects to before you quote.

**Who to sell it to.** Established businesses whose team keeps copying information between spreadsheets, inboxes and software. The owner wants fewer things falling through the cracks and a clear view of each job.

### How it changes for each client
A builder might need quotes, job progress and invoices. A training provider might need enrolments, documents and student records. Map how the team works, then agree what you will replace, what you will connect and what each person can access. Do not promise to replace every tool without checking it.

**What to show.** Show one job moving from enquiry to quote and delivery in the same record. Show who updates it and what the team no longer needs to copy.

> EXAMPLE: We build one CRM around your business so your team stops re-entering information and chasing job updates.

**My recommendation: use AI arbitrage for this one.** A custom CRM is more difficult and technical than it looks. Get an experienced developer to review the requirements and scope the build before you quote the client. You manage the client and delivery; the developer handles the build.

Understand what the client buys, who needs it and what you would show them.

## 6. AI website agency
**What you sell.** Build websites for businesses that have no useful site or an outdated one. AI helps with the layout, copy and build. You organise their services, photos, contact details and enquiry flow into a site they can actually use.

**Who to sell it to.** Local businesses whose current site makes it hard to understand the service or request a quote. Trades, clinics and professional services are easy starting points.

### How it changes for each client
A trades business might need project photos and a quote form. A clinic might need service pages and online booking. Agree the pages, content, enquiry or booking actions, connections and who maintains the site after launch. A website does not automatically include ads or an AI receptionist.

**What to show.** Open the site as a customer on a phone. Find the service, view the work and submit a test enquiry that reaches the business.

> EXAMPLE: We build local businesses a professional website that makes it easy for customers to understand the service and request a quote.

Understand what the client buys, who needs it and what you would show them.

## 7. AI content engine and editing
**What you sell.** Turn the client’s footage and ideas into a regular supply of edited reels, captions and other content. AI helps with scripts, cuts and captions. You check the edits and send a consistent batch for approval.

**Who to sell it to.** Business owners, creators and brands that need content but cannot keep up with planning and editing. Start with one format and a clear monthly output.

### How it changes for each client
One client supplies filmed videos and needs editing. Another needs ideas, scripts, filming guidance and edits. Agree the formats, number of pieces, turnaround, revisions and approval process. Posting the content is another task to include only if agreed.

**What to show.** Show the raw footage beside one finished edit, then the batch ready for the client’s approval. Be clear on how much content and how many revisions they get.

> EXAMPLE: We turn your raw footage into a regular supply of edited videos, ready for you to approve and post.

Understand what the client buys, who needs it and what you would show them.

## 8. A niche AI automation agency
**What you sell.** Choose a type of business and offer a free AI audit. Find where the team loses time, money or opportunities. Recommend the most valuable first fix, show what it would do and sell the implementation. The audit opens the conversation; the build is the paid service.

**Who to sell it to.** Owners who know AI could help but do not know what to implement. Speak to one business type so each conversation teaches you more about the same workflows.

**How you find the paid project.** Have the owner show you a real workflow: what starts it, who handles it, where they copy information and what happens when it gets delayed. Put a cost on the problem, check the proposed fix with your developer, then show the client what you would implement. Quoting, document collection and invoice follow-up are possibilities to investigate, not ready-made offers to assume they need.

**An agency example.** [LeftClick](https://leftclick.ai/services) advertises custom automation, CRM work, onboarding and reporting, with a diagnostic call before the project. Look at the types of projects it offers and how it starts with understanding the business.

### How it changes for each client
The audit identifies the project; it does not commit you to automating everything. One client might need document collection, another invoice follow-up. Agree one workflow, its inputs and outputs, the systems involved and the exceptions a person handles. Get the delivery person to check the build before quoting.

**What to show.** Walk through a real task with the owner, identify the problem and show the proposed fix. You quote that implementation after checking it with the delivery person.

> EXAMPLE: Know you need AI but not where to start? We’ll audit your business for free and show you the first thing we would automate.

These are offer examples to adapt. Set your target, timing and guarantee around what you can deliver. A straightforward receptionist setup can take 2 to 5 working days once the details and access are ready. Start with one niche, identify a worthwhile problem and use Jarvis to develop the service and offer together.

## Choose Your Niche

Explore 25 types of business and choose who you want to help.

## A niche is the type of customer you serve
“Plumbing businesses” is a niche. “AI receptionist” is a service. Your offer connects the two: answering missed calls for plumbing businesses so they can book more jobs.

Below are 25 niches to explore, with several services and an example problem you could investigate for each. Most services can work across several niches, and one niche can buy several services. These suggestions are not limits. Choose based on what the business needs and can gain from it, not the industry label alone.

### Two ways to start
**You already like a service:** look for a niche where that service solves a valuable problem. Compare how other agencies serve those businesses and whether there is a gap in the location, customer type or service they provide.

**You already know a niche:** start there. For a custom automation agency, speak to owners about how their business works before deciding what to build. An AI audit is a conversation where you find useful improvements, then recommend and quote the specific project.

### What makes a niche a good fit?
Look for businesses that can gain enough from the result to pay for your service. A business selling valuable jobs, or handling lots of customers, may have more to gain from a small improvement.

Your knowledge of the industry also helps. Do you understand the work? Can you explain the problem in their language? Is there a clear reason they would want it fixed?

Fewer competing providers can create an opening, but it only matters if customers want the service. Choose the service and niche together, then check the problem with real businesses. Staff count alone does not tell you what a business can afford.

## Trades and home services

### Plumbers
**Services that could fit:** AI receptionist, website, old-lead follow-up or custom CRM.
**One problem to explore:** After-hours enquiries when the team cannot answer.

### Electricians
**Services that could fit:** AI receptionist, website, quote follow-up or custom automation.
**One problem to explore:** New customer calls missed while working on site.

### Roofers
**Services that could fit:** Unsold-quote recovery, AI receptionist, website or custom CRM.
**One problem to explore:** Estimates sent to homeowners who have not decided.

### HVAC companies
**Services that could fit:** Customer reactivation, AI receptionist, enquiry follow-up or custom CRM.
**One problem to explore:** Previous customers who may need another service or maintenance visit.

### Landscapers
**Services that could fit:** Website, AI receptionist, quote follow-up or content engine.
**One problem to explore:** Customers need to see past work and request a quote.

## Clinics and appointment businesses

### Dental clinics
**Services that could fit:** AI receptionist, enquiry follow-up, customer reactivation or website.
**One problem to explore:** Treatment enquiries that do not reach a consultation.

### Physiotherapy clinics
**Services that could fit:** AI receptionist, enquiry follow-up, customer reactivation or website.
**One problem to explore:** Patients trying to book while reception is busy.

### Veterinary practices
**Services that could fit:** AI receptionist, website or custom admin automation.
**One problem to explore:** Routine booking calls that interrupt the front desk; urgent cases need a human.

### Med spas
**Services that could fit:** Enquiry follow-up, AI receptionist, content engine or website.
**One problem to explore:** People asking about treatments but not booking a consultation.

### Gyms and fitness studios
**Services that could fit:** Old-lead recovery, enquiry follow-up, content engine or website.
**One problem to explore:** People who enquired about joining but never started.

## Property and construction

### Real estate agencies
**Services that could fit:** Content engine, enquiry follow-up, AI receptionist or custom CRM.
**One problem to explore:** Agents with property footage but too little time to edit it.

### Property managers
**Services that could fit:** AI receptionist, custom CRM, website or maintenance-request automation.
**One problem to explore:** Maintenance requests copied between inboxes and job systems.

### Residential builders
**Services that could fit:** Custom CRM, quote follow-up, website or AI receptionist.
**One problem to explore:** Quotes, jobs and updates spread across different tools.

### Renovation companies
**Services that could fit:** Quote recovery, AI receptionist, website or content engine.
**One problem to explore:** Customers with outstanding renovation proposals.

### Commercial cleaners
**Services that could fit:** Outbound appointment setting, website, AI receptionist or custom CRM.
**One problem to explore:** Finding and starting conversations with businesses needing a cleaning provider.

## Professional and B2B services

### Recruitment agencies
**Services that could fit:** Outbound appointment setting, custom CRM, content engine or custom automation.
**One problem to explore:** Repeated candidate and client admin across several systems.

### Accounting firms
**Services that could fit:** Document automation, AI receptionist, website or content engine.
**One problem to explore:** Chasing client documents and tracking what is still missing.

### Law firms
**Services that could fit:** AI receptionist, enquiry follow-up, website or custom intake automation.
**One problem to explore:** New enquiries that need details collected and routing to the right person.

### IT service providers
**Services that could fit:** Outbound appointment setting, custom CRM, website or content engine.
**One problem to explore:** Finding businesses suited to their support service.

### Training providers
**Services that could fit:** Enquiry follow-up, custom CRM, website or admin automation.
**One problem to explore:** Enquiries, enrolments and learner records handled in separate places.

## Other service businesses

### Auto repair shops
**Services that could fit:** AI receptionist, customer reactivation, website or enquiry follow-up.
**One problem to explore:** Booking requests while the team is in the workshop.

### Pest control companies
**Services that could fit:** AI receptionist, website, customer reactivation or enquiry follow-up.
**One problem to explore:** Customers need clear service information and an easy quote request.

### Pet groomers
**Services that could fit:** AI receptionist, website, customer reactivation or content engine.
**One problem to explore:** Booking calls missed while handling animals.

### Coaches and consultants
**Services that could fit:** Content engine, enquiry follow-up, website or custom CRM.
**One problem to explore:** Long videos that could become a regular supply of short clips.

### Wedding and event venues
**Services that could fit:** Enquiry follow-up, AI receptionist, content engine or website.
**One problem to explore:** People asking about dates and packages but not booking a viewing.

## Choose one service and one niche
You do not need to be certain forever. Choose one combination to investigate so Jarvis can research something specific.

```
Use the offer menu skill to help me choose one service and niche. Ask about my experience, interests, location and any service I already like. Compare up to three options and help me choose one.

```
When you have chosen, continue to the finished offer example. Then you will build yours step by step.

## What an Irresistible Offer Looks Like

See a complete roofing offer, why it works and where you use it.

See one complete offer before writing yours.

Jarvis uses the offer creation skill to turn your buyer, problem and solution into six lines. First, see the finished example so you know what you are building.

An offer tells the buyer what you will do for them. Here is a roofing recovery offer written in the same six lines you will use for yours.

![A worked example. The target and guarantee need checking before you sell it.](images/roofing-offer-specific-v3.svg)

The roofer wants more paid jobs. The system follows up quotes they have already sent, so the offer does not depend on buying more ad traffic. The number and guarantee need a large enough pipeline and a delivery plan behind them.

## Why this makes it easy to say yes
You are offering the thing the roofer actually wants: more paid jobs. There is a specific target, a clear timeframe and a guarantee that reduces their risk.

They can see how it works: follow up quotes they have already sent. They do not need to spend more on ads to create another batch of enquiries. When the target is realistic for their pipeline and they believe you can deliver it, the offer becomes an easy decision.

## Where do you actually use your offer?
Your offer is the promise you repeat throughout your marketing and sales. The wording can change to fit the format, but the result you promise stays the same.

- **Landing page:** the headline says what they get; the subheadline explains how.
- **Ads:** lead with the result and give them a reason to learn more.
- **Emails and DMs:** explain who you help and what you can do for them.
- **VSL:** explain the problem, the result and how your service delivers it.
- **Sales calls and proposals:** explain what you will do for that business and the terms you agree.

> EXAMPLE: **Headline:** We’ll get you 5 more roofing jobs in 30 days. Or we work for free.

**Subheadline:** We build and run an AI follow-up system that turns your unsold roof estimates into paid jobs, without increasing your ad spend.

That is the shape of the roofing example. The number needs a suitable pipeline and a delivery plan behind it.

The headline sells the result. The subheadline explains the mechanism. The VSL explains the service in more depth. Your application finds the right businesses, then the booking page gets them onto a call.

## Create Your Offer

Use these four prompts in order to finish your offer with Jarvis.

Keep this in the same Jarvis project with your skill pack loaded. Jarvis uses your earlier answers, researches the service and writes the offer. You choose what to keep.

Start with who you can understand and reach.

## Choose who you want to help
Start with a business you know or can reach. If you already picked a service, tell Jarvis and find the buyer who needs it. If you have no experience, say that. Jarvis should ask about your interests, access and location before recommending options.

> EXAMPLE: **You:** “I worked in a roofing office. I want to work with residential roofers in Dallas.”

**Choice:** Residential roofing company owners in Dallas. That is who the rest of the example is about.

```
Use the offer menu skill to help me choose one niche from my background, interests and any service I already have in mind. Ask what you need, then save my chosen buyer and location.

```
**Before continuing:** answer Jarvis’s questions and choose one buyer. Don’t move on with a list of five niches.

Use that buyer to choose one problem and service.

## Find a problem they would pay to solve
Now Jarvis researches that buyer and matches a useful service to the problem. You can use the service examples, an offer found elsewhere or deeper custom research.

> EXAMPLE: **Problem to investigate:** The roofer has unsold estimates but no consistent follow-up.

**Service:** Follow up eligible estimates and bring interested homeowners back to the sales team.

**Why it matters:** They already spent time winning the enquiry and preparing the quote.

```
Use the offer menu skill to research my chosen buyer, recommend one worthwhile problem and service with real examples. Show how to estimate what the problem costs using the owner’s numbers, and explain what I need to confirm with owners.

```
**Before continuing:** choose the problem you can explain. Public research gives you a starting point; owner conversations check whether it is real for them.

Know the delivery behind the promise.

## Know what the service actually does
Get clear on the workflow and delivery before you promise a result.

> EXAMPLE: **The roofing service:** Find eligible unsold estimates, send approved follow-up, handle agreed questions and pass interested homeowners to the sales rep. The rep still answers technical questions, closes and delivers the roofing job.

**Check before selling:** access to the CRM, the usable pipeline, the delivery cost and whether your team or developer can build it.

```
Use the offer menu skill and my saved decisions to explain the problem, workflow, client responsibilities and delivery route in plain language. Save the service brief and flag the facts we must check before promising a result.

```
**Before continuing:** explain the service in two sentences. Take technical gaps to your developer or technical CSM.

Turn the saved service brief into the six lines.

## Turn that service into the offer
The offer creation skill now uses the saved brief. You should not need to explain the whole business again.

> EXAMPLE: **Niche:** Residential roofers in Dallas with eligible unsold estimates.
**Outcome:** Five more paid roofing jobs.
**Timeframe:** Within 30 days of campaign launch.
**Risk reversal:** Work free until the agreed target is reached.
**Authority / proof:** A working demonstration of the follow-up workflow.
**Unique mechanism:** The Estimate Recovery System.

```
Use my saved service brief and the offer creation skill to write my six lines. Reuse my decisions and mark anything we still need to confirm.

```
**Before continuing:** make sure the offer matches the service you understand and can deliver. Ask Jarvis to save the chosen version.

Then [build your landing page](#m5-build-the-page) from that same offer. The headline sells the result; the subheadline explains how.

