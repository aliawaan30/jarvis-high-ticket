Start with implementation/START-HERE.md. It explains the complete package, the student journey and what to connect in Jarvis 2.0.
